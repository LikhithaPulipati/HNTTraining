package com.app;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import com.app.model.Customer;
import com.app.model.Item;
import com.app.model.Order;

public class ListIterations {

	public static void main(String[] args) throws ParseException {

		SimpleDateFormat format = new SimpleDateFormat("MM-dd-yyyy");
		Date start = format.parse("01-01-2022");
	     Date end = format.parse("10-31-2022");
		//Order order = new Order();
		//Item item = new Item();

		Customer customer1 = new Customer(1, "Tom", "male", "Bangalore");
		Customer customer2 = new Customer(2, "Mike", "male", "Delhi");
		Customer customer3 = new Customer(3, "Miley", "female", "Pune");
		Customer customer4 = new Customer(4, "Kunal", "male", "Delhi");
		Customer customer5 = new Customer(5, "Sakshi", "female", "Delhi");
		
		Order o1 = new Order(1, "delivered", format.parse("11-12-2021"), format.parse("11-14-2021"), 
				Arrays.asList(new Item(134, "Moto24", 15000, "Mobiles"), new Item(204, "Acer", 70000, "Laptops")),
				customer1);
		Order o2 = new Order(2, "delivered", format.parse("05-19-2022"), format.parse("05-24-2022"),
				Arrays.asList(new Item(204, "Acer", 70000, "Laptops")), customer4);
		Order o3 = new Order(3, "delivered", format.parse("07-31-2021"), format.parse("08-04-2021"),
				Arrays.asList(new Item(210, "iPhone", 45000, "Mobiles"), new Item(215, "Shirt", 1500, "Shirts")),customer2);
		Order o4 = new Order(4, "pending", format.parse("10-29-2022"), format.parse("10-30-2021"),
				Arrays.asList(new Item(204, "Acer", 70000, "Laptops"), new Item(215, "Shirt", 1500, "Shirts")),customer3);
		Order o5 = new Order(5, "pending", format.parse("10-30-2021"), format.parse("10-30-2021"),
				Arrays.asList(new Item(134, "Moto24", 15000, "Mobiles")), customer5);
		List<Order> customerOrders = Arrays.asList(o1,o2,o3,o4,o5);
		

		Map<Integer, Order> customerOrderMap = new HashMap<>();

		customerOrderMap.put(1,new Order(1, "delivered", format.parse("11-12-2021"), format.parse("11-14-2021"), 
						Arrays.asList(new Item(134, "Moto24", 15000, "Mobiles"), new Item(204, "Acer", 70000, "Laptops")),
						customer1));
		customerOrderMap.put(2, new Order(2, "delivered", format.parse("05-19-2022"), format.parse("05-24-2022"),
				Arrays.asList(new Item(204, "Acer", 70000, "Laptops")), customer4));
		customerOrderMap.put(3, new Order(3, "delivered", format.parse("07-31-2021"), format.parse("08-04-2021"),
				Arrays.asList(new Item(210, "iPhone", 45000, "Mobiles"), new Item(215, "Shirt", 1500, "Shirts")),customer2));
		customerOrderMap.put(4, new Order(4, "pending", format.parse("10-29-2022"), format.parse("10-30-2021"),
				Arrays.asList(new Item(204, "Acer", 70000, "Laptops"), new Item(215, "Shirt", 1500, "Shirts")),customer3));
		customerOrderMap.put(5, new Order(5, "pending", format.parse("10-30-2021"), format.parse("10-30-2021"),
				Arrays.asList(new Item(134, "Moto24", 15000, "Mobiles")), customer5));
		
		List<Item> mobileItems =  customerOrderMap.values().stream().flatMap(
				order -> order.getItems().stream().filter(i ->i.getCategory()=="Mobiles")).distinct().collect(Collectors.toList());
		System.out.println(mobileItems);
		
		List<Item> mobileItemsWithPriceRange =  customerOrderMap.values().stream().flatMap(
				order -> order.getItems().stream().filter(i ->i.getCategory()=="Mobiles" && i.getPrice() >20000)).distinct().collect(Collectors.toList());
		System.out.println(mobileItemsWithPriceRange);
		
		List<Item> notMobiles =  customerOrderMap.values().stream().flatMap(
				order -> order.getItems().stream().filter(i ->i.getCategory() != "Mobiles")).distinct().collect(Collectors.toList());
		System.out.println(notMobiles);
		
		/*List<Item> discountLaptop =  customerOrderMap.values().stream().flatMap(
				order -> order.getItems().stream().filter(i ->i.getCategory() == "Laptops").filter(j-> j.getPrice()).map(j -> j-(5/100)*j).distinct().collect(Collectors.toList());
		System.out.println(discountLaptop);*/
		
		/*List<Customer> femaleCustomers =  customerOrderMap.values().stream().
				flatMap(order -> order.getCus()).collect(Collectors.toList());
				//flatMap(
				//order -> order.getCus().getGender().stream()).filter(c ->l.())).collect(Collectors.toList());
		System.out.println(femaleCustomers);*/
		
	/*	List<Item> ordersInRangeDated =  customerOrderMap.values().stream().flatMap(
				order -> order.getOrderDate().after(format.parse(null))).distinct().collect(Collectors.toList());
		System.out.println(ordersInRangeDated);*/
		
		//List<Item> ordersInRangeDated =  customerOrderMap.values().stream().flatMap(order -> order.getOrderDate().)
	}

}
