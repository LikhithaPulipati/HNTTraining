package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java8LambdasApplication {

	public static void main(String[] args) {
		SpringApplication.run(Java8LambdasApplication.class, args);
		
		
		
	}

}
