package com.app.exceptions;

public class OrderException extends Exception {

	public OrderException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public OrderException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public OrderException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public OrderException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}