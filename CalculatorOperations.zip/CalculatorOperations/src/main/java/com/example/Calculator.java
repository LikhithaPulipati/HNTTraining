package com.example;



public class Calculator {
	
	public static int division(int num1, int num2) {
		if (num2 ==0) {
			throw new ArithmeticException("number cannot be divided by 0"); 
		}
		return num1/num2;
	}

}
