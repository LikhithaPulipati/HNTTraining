import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;



public class LambdaExecution {
	
	public static void main(String[] args) {
		
		Course course1 = new Course(1,"SSC","Akhil",12,100000);
		Course course2 = new Course(2,"Inter","Bindhu",12,250000);
		Course course3 = new Course(3,"Diploma","Charitha",24,300000);
		Course course4 = new Course(4,"B.tech","Akhil",15,100000);
		Course course5 = new Course(5,"B.Pharm","Akhil",15,100000);
		Course course6 = new Course(6,"GRE","Akhil",15,100000);
		Course course7 = new Course(7,"IELTS","Akhil",15,100000);
		Course course8 = new Course(8,"CAT","Akhil",15,100000);
		Course course9 = new Course(9,"JEE","Akhil",15,100000);
		Course course11 = new Course(10,"NEET","Akhil",15,100000);
		Course course10 = new Course(11,"B.Arch","Akhil",15,100000);
		Course course12 = new Course(12,"UPSC","Akhil",15,100000);
		Course course13 = new Course(13,"IES","Akhil",15,100000);
		Course course14 = new Course(14,"CLAT","Akhil",15,100000);
		Course course15 = new Course(15,"CDS","Akhil",15,100000);
		
		List<Course> courseLists =  Arrays.asList(course1,course2,course3,course4,course5,course6,course7,course8,course9,course10,course11,course12,course13,course14,course15);
		Comparator<Course> reverseComparator = Collections.reverseOrder();
		 Collections.sort(courseLists, reverseComparator);
		
		
		/*List<Item> mobileItemsWithPriceRange =  customerOrderMap.values().stream().flatMap(
				order -> order.getItems().stream().filter(i ->i.getCategory()=="Mobiles" && i.getPrice() >20000)).distinct().collect(Collectors.toList());*/
		System.out.println(courseLists);
		
	}

}
