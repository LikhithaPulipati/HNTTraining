/**
 * 
 */
/**
 * @author Dell
 *
 */
module ArrayListsLambda {
}